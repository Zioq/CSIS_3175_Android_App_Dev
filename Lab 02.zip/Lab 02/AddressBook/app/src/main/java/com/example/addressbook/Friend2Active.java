package com.example.addressbook;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Friend2Active extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend2_active);
    }
}